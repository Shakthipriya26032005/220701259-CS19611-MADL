package com.example.lazzylogger

data class DiaryEntry(val id: Int, val title: String, val content: String)
